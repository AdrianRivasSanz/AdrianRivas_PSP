package com.example.entrega_final.model

data class Libros(var nombre: String, var genero:String, var imagen:Int):java.io.Serializable