package com.example.entrega_final.model

data class Usuario(var nombre: String, var password: String) : java.io.Serializable